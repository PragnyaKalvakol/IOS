//
//  ViewController.swift
//  VowelTester
//
//  Created by Kalvakol,Pragnya on 8/30/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var enteredText: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitButtonClicked(_ sender: UIButton) {
  
    //read the text from the text field and ssign it to a local variable.
    var text = enteredText.text!
    //check the text has vowel or not.
    if(text.contains("a") || text.contains("e") || text.contains("i") || text.contains("o") || text.contains("u")) {
        //vowel is in text
        displayLabel.text = "The text has vowel."
        
    }
        else {
            displayLabel.text = "The text has no vowel."
        }
    }
}


