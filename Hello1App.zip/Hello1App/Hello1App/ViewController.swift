//
//  ViewController.swift
//  Hello1App
//
//  Created by Kalvakol,Pragnya on 8/30/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func submitButtonClicked(_ sender: UIButton) {
        //read the text from text field and assign it to a local variable.
        var name = nameOutlet.text!
        
        
        //assign the data to the (entered name) to the display label.
        
        displayLabel.text = "Hello,\(name)!"
    }
}

