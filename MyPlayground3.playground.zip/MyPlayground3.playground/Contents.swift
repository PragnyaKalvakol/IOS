import UIKit
import Security

var greeting = "Hello, playground"
print(greeting ,2)
print("hai"+greeting)
//print("pandhi"+2) cannot concatinate with different  data type
print("hello world \(greeting)")
 var age=23
//for multi line string we use """
print("""
      hello
      world!
      """)
//\r - carriage return generally it will start with new line
print("Hello All ,\rWelcome to swift programming \rI would like to discuss About \rAvengers")
//let= constant
//var = general variable
//= ki mundhu venaka space vundali
//comma use chestha , ki tharavatha space vundali
let welcomeMessage = "Hello!"
print(welcomeMessage, " all")

//variable declaration var variablename : datatype
var S:String = "gaddi"
 S = "piku"
print(S)


print("Welcome to swift Programming")
print("Fall 2021")
print("******************")
print("welcome to Swift Progrsmming ", terminator: "#")
print("harikiran")


//if we use the ,  space will be the default seperator untill or unless we give the seperator attribute


var h = "joker"
var k = "poker"
print(h,"-",k)


var k1 :String = "king"
print(k1)
var h1="car"
print(h1)



var hin = (bin : 2 , kin : 3 , terry : 4)
print(hin)
print(hin.bin)
print(hin.bin , terminator: "*")
print(hin.kin)

