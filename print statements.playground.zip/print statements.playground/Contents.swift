import UIKit

var greeting = "Hello, playground"
print("Hello world!")
print(greeting)
print("Hi",12,11.1)

print("Hello" + greeting)

var age = 22
print("My age is \(age)")

//print("My age is " + (age))

print("""
Hello
World
""")

print("Hello all,\rWelcome to swift")

let welcomemessage: String = "Hello"
      print(welcomemessage , "All")
//welcomemessage = "Goodbye"   cannot change the constants, welcome message is constant

var name: String = "Jihn"
print(name,2,"smith")

print("welcome to sp")
print("fall")
print("welcome to sp", terminator: "$")
print("fall")

var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

let pi = 3.14
print(pi)

//var age : Int = 22
age = age * 2
print(age)

var aweMessage = "This is superb"
print(aweMessage)
print("aweMessage")

var course1 = "ios"
var course2 = "jva"
print(course1,course2)
print(course1,"-",course2)


var httpError  = (errorCode : 404  , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )


var namee = ("John","Smith")
var fName = namee.0
var lName = namee.1
print(fName , terminator : "&")
print(lName)


var origin = (x : 0 , y : 0)
var point = origin
print(point)
